<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
    --blue: #007bff;
    --indigo: #6610f2;
    --purple: #6f42c1;
    --pink: #e83e8c;
    --red: #dc3545;
    --orange: #fd7e14;
    --yellow: #ffc107;
    --green: #28a745;
    --teal: #20c997;
    --cyan: #17a2b8;
    --white: #fff;
    --gray: #6c757d;
    --gray-dark: #343a40;
    --primary: #ff623e;
    --secondary: #3362c1;
    --success: #3e9ea9;
    --info: #2a3775;
    --warning: #ff971b;
    --danger: #ff2c2c;
    --light: #f8f9fa;
    --dark: #343a40;
    --breakpoint-xs: 0;
    --breakpoint-sm: 576px;
    --breakpoint-md: 768px;
    --breakpoint-lg: 992px;
    --breakpoint-xl: 1200px;
    --font-family-sans-serif: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
    --font-family-monospace: SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
    line-height: 1.5;
    text-align: left;
    font-weight: 400!important;
    font-size: 1.125rem;
    font-family: Fira Sans Condensed,Fira Sans,Arial,sans-serif;
    letter-spacing: 0;
    word-spacing: 0;
    color: #7f94a9;
    box-sizing: border-box;
    flex-direction: column;
    display: flex;
</style>
</head>
<body>
   <div id="DEM_SEXE-wrapper" class="FieldWrapper RadioField DEM_SEXE field-default  "><div class="FieldView DaisyFieldView undefined field-default RadioField DEM_SEXE "><div class="FieldView-flex-container"><label class="Label ">Civilité</label></div><div class="app-row app-field"><div class="app-col-xs-12 app-col-sm-12 app-col-md-12 Field"><div class="ButtonField always-flex-direction-row"><div class="ButtonField-Block button-field-femme-DEM_SEXE app-col-xs-6 app-col-sm-4 app-col-md-4"><input type="radio" id="DEM_SEXE_femme" name="DEM_SEXE" class="checkbox-field" tabindex="1" value="femme" style="display: none;"><div class="Button ButtonField-Block-Button ButtonField-value-femme   hasIcon  field-default" tabindex="0"><span class="Icon Button-icon icon-lesfurets icon-form-femme"></span><label class="Button-label" for="DEM_SEXE_femme">Une femme</label><div class="radio-tick icon-lesfurets "></div></div></div><div class="ButtonField-Block button-field-homme-DEM_SEXE app-col-xs-6 app-col-sm-4 app-col-md-4"><input type="radio" id="DEM_SEXE_homme" name="DEM_SEXE" class="checkbox-field" tabindex="2" value="homme" style="display: none;"><div class="Button ButtonField-Block-Button ButtonField-value-homme   hasIcon  field-default" tabindex="0"><span class="Icon Button-icon icon-lesfurets icon-form-homme"></span><label class="Button-label" for="DEM_SEXE_homme">Un homme</label><div class="radio-tick icon-lesfurets "></div></div></div></div></div></div></div></div>
 
</body>
</html>
<?php /**PATH C:\laragon\www\assuure\resources\views/test.blade.php ENDPATH**/ ?>